import AICreativeStudio from "./components/AICreativeStudio";

function App() {
  return <AICreativeStudio />;
}

export default App;
